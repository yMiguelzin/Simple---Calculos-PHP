<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        $ar=$_POST["numr"];
        $lr=$_POST["numr1"];
        
        $calculoretangulo= $ar * $lr;
            
        echo"O valor da area do quadrado é: ".$calculoretangulo;      
        
        ?>
    </body>
</html>
